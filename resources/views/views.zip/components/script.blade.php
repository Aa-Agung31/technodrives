    <!-- jquery js -->  
    <script src="assets/js/vendor/jquery-3.6.2.min.js"></script>
    <!-- bootstrap js -->   
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- carousel js -->
    <script src="assets/js/owl.carousel.min.js"></script>
    <!-- counterup js -->
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- waypoints js -->
    <script src="assets/js/waypoints.min.js"></script>
    <!-- wow js -->
    <script src="assets/js/wow.js"></script>
    <!-- imagesloaded js -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <!-- venobox js -->
    <script src="venobox/venobox.js"></script>
    <!--  animated-text js -->  
    <script src="assets/js/animated-text.js"></script>
    <!-- venobox min js -->
    <script src="venobox/venobox.min.js"></script>
    <!-- isotope js -->
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!-- jquery meanmenu js --> 
    <script src="assets/js/jquery.meanmenu.js"></script>
    <!-- jquery scrollup js --> 
    <script src="assets/js/jquery.scrollUp.js"></script>
    <script src="assets/js/jquery.barfiller.js"></script>
    <script src="assets/js/typed.js"></script>
    <!-- jquery js -->  
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script src="assets/js/vanilla-tilt.min.js"></script>
    <!-- partial -->
     
    <!-- theme js -->   
    <script src="assets/js/theme.js"></script>