<div class="breadcumb-area about">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="breadcumb-content">
          <h4><?php echo $title;?></h4>
          <ul class="breadcumb-list">
            <li><a href="index.html">Home</a></li>
            <li class="list-arrow">&lt;</li>
            <li><?php echo $title;?></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>